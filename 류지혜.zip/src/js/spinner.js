export function createSpinner(parent) {
  const spinnerAreaEl = parent.children[1];
  console.log(spinnerAreaEl);

  const imageEl = document.createElement("img");
  imageEl.alt = "spinner";
  imageEl.src = "./src/image/spinner.gif";

  spinnerAreaEl.children[0].append(imageEl);
  // console.log("스피너:", parent);

  /* spinner.area에 넣어야 하는데 얘네에 접근하려면 배열로 접근해야해 
  근데 문제가 지금 area가 2군데라 
  parent = topNewsList 를 받은 다음 해당 parent 안에 있는
  
  spinner-area에 접근하게 해줘야 한다 
   */
}
