export function createSpinner(parent) {
  const spinnerAreaEl = document.createElement('div');
  const imageEl = document.createElement('img');
  imageEl.alt = 'spinner';
  imageEl.src = './src/image/spinner.gif';

  spinnerAreaEl.appendChild(imageEl);
}
