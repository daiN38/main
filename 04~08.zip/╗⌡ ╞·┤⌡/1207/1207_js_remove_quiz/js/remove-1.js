// const a = document.querySelector('h1');
// a.addEventListener('click', function(){
//     a.remove();
// });


const title = document.querySelector('h1');

title.addEventListener('click', () => {
    title.remove();
})

// 문서에서 h1 태그를 선택해서 변수에 저장
// 그 저장된 변수 클릭 시 함수 실행